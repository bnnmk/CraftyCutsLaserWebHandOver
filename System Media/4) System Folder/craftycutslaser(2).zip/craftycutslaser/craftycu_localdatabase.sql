-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- 主机: localhost:3306
-- 生成日期: 2016-02-06 15:31:26
-- 服务器版本: 5.5.47-cll
-- PHP 版本: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `craftycu_localdatabase`
--

-- --------------------------------------------------------

--
-- 表的结构 `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(25) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `categories`
--

INSERT INTO `categories` (`id`, `category`, `description`) VALUES
(1, 'Acrylic Shapes', '<p>The acrylic shapes category is bla bla bla</p>\r\n'),
(2, 'Wooden Shapes', ''),
(3, 'Paper Shapes', ''),
(4, 'Leather, Fabric & Felt', ''),
(5, 'Findings', ''),
(6, 'Studio Clear­out Sale', '');

-- --------------------------------------------------------

--
-- 表的结构 `colors`
--

CREATE TABLE IF NOT EXISTS `colors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(30) NOT NULL,
  `image_url` varchar(30) NOT NULL,
  `Extra_price` double DEFAULT NULL,
  `outofstock` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `contents`
--

CREATE TABLE IF NOT EXISTS `contents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pageName` varchar(45) NOT NULL,
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='static page: store all the content for the pages in the system' AUTO_INCREMENT=10 ;

--
-- 转存表中的数据 `contents`
--

INSERT INTO `contents` (`id`, `pageName`, `content`) VALUES
(2, 'About us', '<div><span style="font-size:12px">Pre-made Creative Laser Cut Supplies Crafty Cuts offers pre-made creative and fun product solutions for independent craft and design based businesses.</span></div>\r\n\r\n<div><span style="font-size:12px">We take our 12 year background in product design and development (for some of Australia biggest retailers) as well as 15 years as a graphic designer and design fun and unique shapes to help you further your own small niche business. Our own successful laser cut range was stocked in over 150 stores over the past 8 years.</span></div>\r\n\r\n<div><span style="font-size:12px">We glued over 100000 pairs of mini earrings during that time - phew! We are no longer selling our finished items to stores but now putting our laser cutting machine to good use and making our fun and unique designs available in small runs (or large if need be - just convo us!) suitable for your small indie businesses.</span></div>\r\n\r\n<div><span style="font-size:12px">All our cuts are for you to make your own and re-sell to your peeps. We do not offer a custom cutting service.</span></div>\r\n\r\n<div><span style="font-size:12px">What you get when you buy our cuts is our extensive experience in mass market product design and development - we do all the R&amp;D and product development for you and we are always regularly adding new designs and keeping up with all the latest trends. We have our own brick and mortar gift store (Proudly stocking and supporting over 100 ETSY makers).</span></div>\r\n\r\n<div><span style="font-size:12px">We have been trading for 6 years so all crafty cuts goodies are designed from a buyer perspective. We do not sell crafty cuts pieces in our store - these items are only available via our etsy store Our listings are set up to be a pick and mix - we sell in single pairs or pieces which allow you the buyer to mix the right colour combo&#39;s and quantities you need to suit your market. Easy peasy trial and error with out massive $$ outlays.</span></div>\r\n\r\n<div><span style="font-size:12px">We know your customers will love our cuts!</span></div>\r\n\r\n<div>&nbsp;</div>\r\n\r\n<div><span style="font-size:12px">COUPON CODE: <strong>100BULK10</strong> - When ordering $99+ excluding shipping - enter 100BULK10 to receive 10% Off</span></div>\r\n\r\n<div><span style="font-size:12px">COUPON CODE: <strong>15OFF150</strong> - When ordering $150+ excluding shipping - enter 15OFF150 to receive 15% Off</span></div>\r\n\r\n<div><span style="font-size:12px">COUPON CODE: <strong>200BULK20</strong> - When ordering $200+ excluding shipping - enter 200BULK20 to receive 20% Off</span></div>\r\n\r\n<div>&nbsp;</div>\r\n'),
(3, 'News', '<p>1. Blue is out of stock&nbsp;</p>\r\n<p>2. Red is back to stock&nbsp;</p>\r\n<p>3. check discout policy</p>'),
(6, 'Disclaimer', NULL),
(7, 'Postage, Payment and Returns', NULL),
(8, 'Privacy Policy', NULL),
(9, 'Terms and Conditions', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `faqs`
--

CREATE TABLE IF NOT EXISTS `faqs` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `sectionname` varchar(20) NOT NULL,
  `detail` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `faqs`
--

INSERT INTO `faqs` (`id`, `sectionname`, `detail`) VALUES
(1, 'Ordering', '<h3><a href="http://asos.custhelp.com/app/answers/detail/a_id/9/p/91" style="outline: none; color: black; text-decoration: none; line-height: 26px; font-weight: bold;">What do I do if I receive a faulty item in my order?</a></h3>\r\n\r\n<ol start="1">\r\n	<li><span style="font-size:16px"><a href="http://asos.custhelp.com/app/answers/detail/a_id/9/p/91" style="outline: none; color: black; text-decoration: none; line-height: 18px;">We want to sort out any issues with faulty items straightaway. As soon as you discover a fault, please&nbsp; contact our Customer Care team with: The order number The faulty item&#39;s name and number A...</a></span></li>\r\n	<li><span style="font-size:16px"><a href="http://asos.custhelp.com/app/answers/detail/a_id/10/p/91" style="outline: none; color: black; text-decoration: none; line-height: 26px; font-weight: bold;">I have an incorrect item in my order, what do I do?</a></span><span style="font-size:16px"><a href="http://asos.custhelp.com/app/answers/detail/a_id/10/p/91" style="outline: none; color: black; text-decoration: none; line-height: 18px;">We want to sort out any issues with incorrect items straight away. Please&nbsp; contact our Customer Care team with your order number and the incorrect item&#39;s name and product number. We&#39;ll get back...</a></span></li>\r\n	<li><span style="font-size:16px"><a href="http://asos.custhelp.com/app/answers/detail/a_id/26/p/91" style="outline: none; color: black; text-decoration: none; line-height: 26px; font-weight: bold;">Can I cancel my order after I&#39;ve placed it?</a></span><span style="font-size:16px"><a href="http://asos.custhelp.com/app/answers/detail/a_id/26/p/91" style="outline: none; color: black; text-decoration: none; line-height: 18px;">There are varying time limits in which you can cancel your order dependent on which delivery option you&#39;ve chosen: Next Day Delivery &amp; Evening Next Day Delivery - 15 minutes after completing your...</a></span></li>\r\n	<li><span style="font-size:16px"><a href="http://asos.custhelp.com/app/answers/detail/a_id/7/p/91" style="outline: none; color: black; text-decoration: none; line-height: 26px; font-weight: bold;">Can I amend my order after I&#39;ve placed it?</a></span><span style="font-size:16px"><a href="http://asos.custhelp.com/app/answers/detail/a_id/7/p/91" style="outline: none; color: black; text-decoration: none; line-height: 18px;">We&#39;re really quick at packing your order up which means we can&#39;t make any changes once you&#39;ve placed it. This includes changing the delivery option, delivery address or payment method. However, you...</a></span></li>\r\n	<li><span style="font-size:16px"><a href="http://asos.custhelp.com/app/answers/detail/a_id/2555/p/91" style="outline: none; color: black; text-decoration: none; line-height: 26px; font-weight: bold;">Information about EU withdrawal/cancellation rights</a></span><span style="font-size:16px"><a href="http://asos.custhelp.com/app/answers/detail/a_id/2555/p/91" style="outline: none; color: black; text-decoration: none; line-height: 18px;">&bull;&nbsp;The Consumer Contracts (Information, Cancellation and Additional Charges) Regulations 2013 (UK) advise you have fourteen calendar days to cancel the contract for your order with us and we will...</a></span></li>\r\n</ol>\r\n'),
(2, 'Delivery', '<ol style="margin: 0px; padding: 3px 0px 0px; list-style: none; font-family: futura-pt, Tahoma, Arial, Verdana, sans-serif; font-size: 13px;" start="1">\r\n<li class="show_li" style="margin: 0px; padding: 0px 32px 3px 0px; list-style: none; border-bottom-width: 0px; border-bottom-style: dotted; border-bottom-color: #a9a9a9;"><span class="rn_Element1" style="font-size: 16px; line-height: 24px; display: block; letter-spacing: 0.5px;"><a style="outline: none; color: black; line-height: 26px; font-weight: bold;" href="http://asos.custhelp.com/app/answers/detail/a_id/51/p/89">How does your UK Standard Delivery service work?</a></span><span class="rn_Element3" style="display: block; font-size: 16px; margin-top: 2px; padding-bottom: 38px; line-height: 24px; letter-spacing: 0.5px;"><a style="outline: none; color: black; text-decoration: none; line-height: 18px;" href="http://asos.custhelp.com/app/answers/detail/a_id/51/p/89">&bull; Delivery is within&nbsp;4 working days* from the moment you submit your order. &bull; Delivery is Monday to Sunday (excluding Public Holidays). &bull; If your order is above &pound;20.00, no delivery charge will...</a></span></li>\r\n<li class="show_li" style="margin: 0px; padding: 0px 32px 3px 0px; list-style: none; border-bottom-width: 0px; border-bottom-style: dotted; border-bottom-color: #a9a9a9;"><span class="rn_Element1" style="font-size: 16px; line-height: 24px; display: block; letter-spacing: 0.5px;"><a style="outline: none; color: black; text-decoration: none; line-height: 26px; font-weight: bold;" href="http://asos.custhelp.com/app/answers/detail/a_id/8/p/89">What should I do if my order hasn''t been delivered yet?</a></span><span class="rn_Element3" style="display: block; font-size: 16px; margin-top: 2px; padding-bottom: 38px; line-height: 24px; letter-spacing: 0.5px;"><a style="outline: none; color: black; text-decoration: none; line-height: 18px;" href="http://asos.custhelp.com/app/answers/detail/a_id/8/p/89">Your estimated delivery date is in your Order Confirmation email &ndash; please allow until this date for your order to arrive. It''s also worth checking if there are&nbsp;any local delays in your area -...</a></span></li>\r\n<li class="show_li" style="margin: 0px; padding: 0px 32px 3px 0px; list-style: none; border-bottom-width: 0px; border-bottom-style: dotted; border-bottom-color: #a9a9a9;"><span class="rn_Element1" style="font-size: 16px; line-height: 24px; display: block; letter-spacing: 0.5px;"><a style="outline: none; color: black; text-decoration: none; line-height: 26px; font-weight: bold;" href="http://asos.custhelp.com/app/answers/detail/a_id/64/p/89">How can I find your international delivery information?</a></span><span class="rn_Element3" style="display: block; font-size: 16px; margin-top: 2px; padding-bottom: 38px; line-height: 24px; letter-spacing: 0.5px;"><a style="outline: none; color: black; text-decoration: none; line-height: 18px;" href="http://asos.custhelp.com/app/answers/detail/a_id/64/p/89">Click here to find out more about international delivery times and costs. Standard and Express delivery services are available for most of the countries that we ship to. Once you have entered the...</a></span></li>\r\n<li class="show_li" style="margin: 0px; padding: 0px 32px 3px 0px; list-style: none; border-bottom-width: 0px; border-bottom-style: dotted; border-bottom-color: #a9a9a9;"><span class="rn_Element1" style="font-size: 16px; line-height: 24px; display: block; letter-spacing: 0.5px;"><a style="outline: none; color: black; text-decoration: none; line-height: 26px; font-weight: bold;" href="http://asos.custhelp.com/app/answers/detail/a_id/50/p/89">How does your UK Next Day Delivery service work?</a></span><span class="rn_Element3" style="display: block; font-size: 16px; margin-top: 2px; padding-bottom: 38px; line-height: 24px; letter-spacing: 0.5px;"><a style="outline: none; color: black; text-decoration: none; line-height: 18px;" href="http://asos.custhelp.com/app/answers/detail/a_id/50/p/89">&bull;&nbsp;Delivery is on the next day (Monday-Sunday) if ordered before&nbsp;midnight&nbsp;(Monday-Friday), and before 5pm&nbsp;(Saturday-Sunday).&nbsp;* &bull; However, Next Day Delivery is not available to...</a></span></li>\r\n<li class="show_li" style="margin: 0px; padding: 0px 32px 3px 0px; list-style: none; border-bottom-width: 0px; border-bottom-style: dotted; border-bottom-color: #a9a9a9;"><span class="rn_Element1" style="font-size: 16px; line-height: 24px; display: block; letter-spacing: 0.5px;"><a style="outline: none; color: black; text-decoration: none; line-height: 26px; font-weight: bold;" href="http://asos.custhelp.com/app/answers/detail/a_id/54/p/89">How does your UK Click &amp; Collect delivery service work?</a></span><span class="rn_Element3" style="display: block; font-size: 16px; margin-top: 2px; padding-bottom: 38px; line-height: 24px; letter-spacing: 0.5px;"><a style="outline: none; color: black; text-decoration: none; line-height: 18px;" href="http://asos.custhelp.com/app/answers/detail/a_id/54/p/89">&bull; Your order will be delivered to a Collect+, Boots or Doddle&nbsp;collection point to pick-up at your convenience. You can select to collect your order from any supermarket, petrol station, shopping...</a></span></li>\r\n</ol>');

-- --------------------------------------------------------

--
-- 表的结构 `finishes`
--

CREATE TABLE IF NOT EXISTS `finishes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- 表的结构 `materials`
--

CREATE TABLE IF NOT EXISTS `materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `orderdetails`
--

CREATE TABLE IF NOT EXISTS `orderdetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `productsdetails_id` int(11) NOT NULL,
  `unitprice` double NOT NULL,
  `quantity` int(5) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `productsdetails_id` (`productsdetails_id`),
  KEY `product_id` (`product_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `shippingaddress` varchar(225) NOT NULL,
  `postcode` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `shippingmethod` varchar(20) NOT NULL,
  `shipping_cost` double NOT NULL,
  `tax_amount` varchar(9) NOT NULL,
  `discount` double NOT NULL,
  `grosstotal` double NOT NULL,
  `total_amount` varchar(9) NOT NULL,
  `status` varchar(15) NOT NULL,
  `tracking_number` int(11) DEFAULT NULL,
  `payment_method` varchar(15) NOT NULL,
  `createdate` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id_fk` (`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `pagematerials`
--

CREATE TABLE IF NOT EXISTS `pagematerials` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `materialname` varchar(40) NOT NULL,
  `detail` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `productName` varchar(255) NOT NULL,
  `status` varchar(20) NOT NULL,
  `categories_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `categories_id` (`categories_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `productsdetails`
--

CREATE TABLE IF NOT EXISTS `productsdetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `color_id` int(11) DEFAULT NULL,
  `size_id` int(11) DEFAULT NULL,
  `material_id` int(11) DEFAULT NULL,
  `finish_id` int(11) DEFAULT NULL,
  `price` varchar(9) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id_fk` (`product_id`),
  KEY `color_id_fk` (`color_id`),
  KEY `finishes_id_fk` (`finish_id`),
  KEY `material_id_fk` (`material_id`),
  KEY `Size_id_fk` (`size_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `productsimages`
--

CREATE TABLE IF NOT EXISTS `productsimages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `image_url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id_fk` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `productsubs`
--

CREATE TABLE IF NOT EXISTS `productsubs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `subcategory_id` (`subcategory_id`),
  KEY `category_id` (`category_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `shippingcosts`
--

CREATE TABLE IF NOT EXISTS `shippingcosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount_from` double NOT NULL,
  `amount_to` double NOT NULL,
  `price` double NOT NULL,
  `type` varchar(20) NOT NULL,
  `upgrade_type` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- 转存表中的数据 `shippingcosts`
--

INSERT INTO `shippingcosts` (`id`, `amount_from`, `amount_to`, `price`, `type`, `upgrade_type`) VALUES
(1, 0, 50, 3, 'Australia', 'Standard Post'),
(2, 0, 50, 5.95, 'Australia', 'Registered Post'),
(3, 0, 50, 10.55, 'Australia', 'Express Post'),
(4, 51, 150, 8.25, 'Australia', 'Standard Post'),
(5, 51, 150, 11.2, 'Australia', 'Registered Post'),
(6, 51, 150, 10.55, 'Australia', 'Express Post'),
(7, 151, 999999999999, 0, 'Australia', 'Express Post'),
(8, 0, 5, 3.75, 'International', 'Standard Post'),
(9, 6, 40, 7.4, 'International', 'Standard Post'),
(10, 41, 125, 16, 'International', 'Standard Post'),
(11, 126, 250, 26.4, 'International', 'Standard Post'),
(12, 251, 999999999999, 0, 'International', 'Express Post');

-- --------------------------------------------------------

--
-- 表的结构 `shoppingcartitems`
--

CREATE TABLE IF NOT EXISTS `shoppingcartitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `productsdetail_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `quantity` varchar(4) NOT NULL,
  PRIMARY KEY (`id`,`user_id`),
  KEY `product_id_fk` (`product_id`),
  KEY `productsdetail_id_fk` (`productsdetail_id`),
  KEY `user_id_fk` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `sizes`
--

CREATE TABLE IF NOT EXISTS `sizes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(30) NOT NULL,
  `Extra_price` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `sliderimages`
--

CREATE TABLE IF NOT EXISTS `sliderimages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imageurl` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `sliderimages`
--

INSERT INTO `sliderimages` (`id`, `imageurl`) VALUES
(1, 'sliderimages/1453643923sky.jpg'),
(2, 'sliderimages/1453643969example.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `subcategories`
--

CREATE TABLE IF NOT EXISTS `subcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subcategory` varchar(50) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=47 ;

--
-- 转存表中的数据 `subcategories`
--

INSERT INTO `subcategories` (`id`, `subcategory`, `category_id`) VALUES
(1, 'Cats and Dogs', 1),
(2, 'Birds', 1),
(3, 'Fruits & Flowers', 1),
(4, 'Cute Things', 1),
(5, 'Geometric Shapes', 1),
(6, 'Animals', 1),
(7, 'Oddball and Kooky', 1),
(8, 'Words and Letters', 1),
(9, 'Small Charms', 1),
(10, 'Great for Mini Earrings', 1),
(11, 'Great for Pendants & Mobie', 1),
(12, 'Great for Brooches & Magn', 1),
(13, 'Great for Dangle Earrings', 1),
(14, 'Cats and Dogs', 2),
(15, 'Birds', 2),
(16, 'Fruits & Flowers', 2),
(17, 'Cute Things', 2),
(18, 'Geometric Shapes', 2),
(19, 'Animals', 2),
(20, 'Oddball and Kooky', 2),
(21, 'Words and Letters', 2),
(22, 'Small Charms', 2),
(23, 'Great for Mini Earrings', 2),
(24, 'Great for Pendants & Mobi', 2),
(25, 'Great for Brooches & Magn', 2),
(26, 'Great for Dangle Earrings', 2),
(27, 'Cats and Dogs', 3),
(28, 'Birds', 3),
(29, 'Fruits & Flowers', 3),
(30, 'Cute Things', 3),
(31, 'Geometric Shapes', 3),
(32, 'Animals', 3),
(33, 'Oddball and Kooky', 3),
(34, 'Words and Letters', 3),
(35, 'Leather', 4),
(36, 'Fabric', 4),
(37, 'Felt', 4),
(38, 'Chains', 5),
(39, 'Cabochons', 5),
(40, 'Earring Settings', 5),
(41, 'Glue', 5),
(42, 'Beads', 5),
(43, 'Starter Kits', 5),
(44, 'Packaging', 5),
(45, 'Tassels and Pom Poms', 5),
(46, 'Assorted Metals Findings', 5);

-- --------------------------------------------------------

--
-- 表的结构 `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `First_Name` varchar(20) NOT NULL,
  `Last_Name` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(10) NOT NULL,
  `post_code` varchar(4) NOT NULL,
  `email` varchar(255) NOT NULL,
  `news_letter` tinyint(1) NOT NULL,
  `password` varchar(255) NOT NULL,
  `token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;


--
-- 转存表中的数据 `users`
--

INSERT INTO `users` (`id`, `First_Name`, `Last_Name`, `address`, `phone`, `post_code`, `email`, `news_letter`, `password`) VALUES
(1, 'Bec', 'Albinson', 'fake street', '0401233267', '3166', 'bec@craftycutslaser.com', 1, '$2y$10$vi127tiKZPw5EW99EtuYxefh8A13BSvPGJYzZHRO52sEXyO2x5g7.', NULL);

--
-- 限制导出的表
--

--
-- 限制表 `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD CONSTRAINT `orders_fk` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  ADD CONSTRAINT `productdetils_fk` FOREIGN KEY (`productsdetails_id`) REFERENCES `productsdetails` (`id`),
  ADD CONSTRAINT `products_fk` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- 限制表 `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- 限制表 `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `categories_id_fk` FOREIGN KEY (`categories_id`) REFERENCES `categories` (`id`);

--
-- 限制表 `productsdetails`
--
ALTER TABLE `productsdetails`
  ADD CONSTRAINT `productsdetails_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `productsdetails_ibfk_2` FOREIGN KEY (`color_id`) REFERENCES `colors` (`id`),
  ADD CONSTRAINT `productsdetails_ibfk_3` FOREIGN KEY (`finish_id`) REFERENCES `finishes` (`id`),
  ADD CONSTRAINT `productsdetails_ibfk_4` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id`),
  ADD CONSTRAINT `productsdetails_ibfk_5` FOREIGN KEY (`size_id`) REFERENCES `sizes` (`id`);

--
-- 限制表 `productsimages`
--
ALTER TABLE `productsimages`
  ADD CONSTRAINT `productsimages_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- 限制表 `productsubs`
--
ALTER TABLE `productsubs`
  ADD CONSTRAINT `prosub_cate_id` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `prosub_fk` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `prosub_sub_id` FOREIGN KEY (`subcategory_id`) REFERENCES `subcategories` (`id`);

--
-- 限制表 `shoppingcartitems`
--
ALTER TABLE `shoppingcartitems`
  ADD CONSTRAINT `shoppingcartItems_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `shoppingcartItems_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `shoppingcartItems_ibfk_3` FOREIGN KEY (`productsdetail_id`) REFERENCES `productsdetails` (`id`);

--
-- 限制表 `subcategories`
--
ALTER TABLE `subcategories`
  ADD CONSTRAINT `subcategories_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
